# Pasos para leer pdfs

## 1. Identificar formato de pdf [ACREDITAR TAMAÑO EMPRESA, PERSONALIZADA, SOLICITAR CREDITOS, ACREDITAR RENTA]

## 2. De cada pdf:
### a. Ubicar las tablas de acuerdo a su posicion
### b. Extraer los datos de las tablas
### c. Exportar las tablas a formato json

